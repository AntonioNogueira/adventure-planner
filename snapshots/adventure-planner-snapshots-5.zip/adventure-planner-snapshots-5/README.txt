Adventure Planner – snapshots batch 5 (latest version after the clean-up, 10 November 2026)

01  Bikepacking Évora → Mértola: bright route, new categories in the legend (Stay, Food, Bike shops, Utilities, Points of interest)
02  A stop's card: categories with places (empty ones hidden), "Add reservation" and "Add a link"
03  Clicking the map: "Mark a place here" – camp spot in Stay, with its own name
04  The marked camp spot on the map
05  Budget: amounts typed over the estimates (↺ goes back)
06  Documents: "Add a link" – paste a Google Maps / Booking / post link
07  Motorcycle Lisbon → Porto: the shops category becomes "Moto shops"
08  Ride on an iPhone: the Go to list (and "Tonight" when tonight's stay is saved)
09  Ride: going to a picked place with turn-by-turn

Note: these were taken from a cloud server that can't reach the main OpenStreetMap places server, so places
came from the backup service (fewer places to stay, no unnamed water points). The live site gets the full data.
