Adventure Planner - test batch 2: off-road routing, topo map, local budget (2026-11-08)

Unpaved share of the route drawn in the app (measured with OpenStreetMap road data):

Trip                                         Off-road ON          Off-road OFF
01 Bikepacking Evora -> Mertola (Google)     158 km, 64% unpaved  145 km, 30% (Google bike route)
02 Adventure moto Evora -> Monsaraz -> Mertola 200 km, 43%        191 km, 0% (Google)
03 Hike Manteigas -> Penhas da Saude -> Covilha (OSM) 23 km, 52% on trails  22 km, 49%
04 Adventure moto Granada -> Almeria (OSM)   185 km, 41%          195 km, 0%
05 Moto Lisboa -> Porto by motorway: budget with fuel and tolls as trip lines (324 km x 5.2 L x 1.74 EUR; 250 toll km x 0.08),
   fuel price and consumption estimated (AUTO), stays "from 3 places", food at local prices.

Engines: bike = BRouter gravel (prefer unpaved, avoid steep climbs); moto = BRouter custom
"easy adventure" profile (good dirt tracks, never footpaths/closed/very rough ways);
hike = BRouter hiking (max T2, marked trails preferred). Google has no off-road option.
Base map: Topo (OpenTopoMap contours and hill shading); Satellite and Hybrid shown in 03/04.
In the sandbox the OpenStreetMap places service (Overpass) was blocked, so OSM trips show
fewer place suggestions.
