Adventure Planner - test snapshots (2026-11-07/08)

Trips planned end to end with the AI planner on both versions:
Google = Adventure Planner (Google Maps); OSM = Adventure Planner Open (OpenStreetMap).
Each trip: 1-route (chat + map), 2-segment (longest day: roads, speed limits, surface, terrain), 3-budget.
The browser region sets language, units and currency (UK = GBP/km, Portugal = PT/EUR,
Brazil = PT-BR/BRL, US = USD/miles).
10-11: the Plans screen when a daily limit is reached (test limits set low on purpose).
In the test sandbox the OpenStreetMap places service (Overpass) was blocked, so OSM trips show
"Night stop at km ..." and no place suggestions; with a normal connection they show towns with lodging.
