Adventure Planner – snapshots batch 3: installable phone app + Ride mode
Trip: Motorcycle, Lisbon -> Faro, 2 days, hotels. GPS position simulated in the browser.

01  iPhone, OSM version: Ride tab on day 1, position on the A2, km left / arrival / speed, iPhone install hint
02  Phone, OSM: 1.3 km off the route -> warning
03  Phone, OSM: day 2 preview while still on day 1
04  Desktop, Google version: following the rider on the route
05  Desktop, Google: off-route warning
06  Desktop, Google: day 2 preview ("75 km from this day's route")
07  App icon (home screen)
