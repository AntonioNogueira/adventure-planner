Adventure Planner – snapshots batch 6 (current version, 10 November 2026)

01  Trip summary (distance and climb; each day keeps its own time)
02  A stop's card on the map, condensed: small Wikipedia photo, 2 places per category, Prices/Tours on the name's line
03  Clicking a day line: details in a banner at the bottom (two columns), the map fitted to the day and free to pan/zoom
04  Zoomed in: the road shows through the route line
05  Clicking the map: "Mark a place here" (a camp spot in Stay)
06  Budget: amounts typed over the estimates
07  Documents: "Add a link"
08  Ride on an iPhone: going to a picked place, turn by turn

Taken from a cloud server that can't reach the main OpenStreetMap places server and is throttled by Wikipedia,
so some categories and photos are missing; the live site gets the full data.
